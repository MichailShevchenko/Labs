import math
a = int(input("Введите число: "))
print(math.sqrt(a))