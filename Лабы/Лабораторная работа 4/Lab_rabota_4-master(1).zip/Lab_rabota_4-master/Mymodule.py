x = int(input("Введите число 1: "))
y = int(input("Введите число 2: "))
def summa(x,y):
	return x+y
print(summa(x,y))
