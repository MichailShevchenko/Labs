import Mymodule
Mymodule.summa(x = int(input()) , y=int(input()))
print(Mymodule.summa)
